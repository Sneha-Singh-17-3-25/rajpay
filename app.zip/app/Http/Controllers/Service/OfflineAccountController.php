<?php

namespace App\Http\Controllers\Service;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Report;
use App\Model\Provider;
use App\Model\NpsAccount;
use App\Model\Company;
use App\Model\Companydata;
use Carbon\Carbon;

class OfflineAccountController extends Controller
{
    public function apply(Request $post, $product, $type)
    {
    	$type = strtolower($type);
        $data["type"]    = $type;
        $data["product"] = $product;
        $data['company'] = Company::where('website', $_SERVER['HTTP_HOST'])->first();

        if($data['company']){
            $data['companydata'] = Companydata::where('company_id', $data['company']->id)->first();
        }

        switch ($product) {
            // case 'nsdl':
            //     return view('apply.nsdlaccount')->with($data);
            //     break;

            case 'nps':
                return view('apply.nps')->with($data);
                break;
            
            default:
                if($post->has("encreqdetails")){
                    \DB::table('microlog')->insert(["product" => "Nsdlbank", 'response' => json_encode($post->all()), 'created_at' => date('Y-m-d H:i:s')]);
                }
                
                if($post->has("debug")){
                    $key= "UBBluRkIcEyhPpVE";
                    $iv = "UBBluRkIcEyhPpVE";
                    $textToDecrypt = $post->encreqdetails;
                    
                    $decrypted = openssl_decrypt($textToDecrypt, 'aes-128-cbc', $key, 0, $iv);
                    dd($textToDecrypt, $decrypted);
                }
                
                if($post->has("txnStatus")){
                    $data["txnid"] = $post->txnid;
                    $report = Report::where('txnid', $post->txnid)->where("status", "pending")->first();
                    
                    if($report){
                        $post["encData"] = $report->description;
                        if($post->txnStatus == "1"){
                            $data['status'] = "success";
                            $data['refno']  = $post->ackNo;
                            $data['remark'] = $post->ackNo;
                        }else{
                            $data['status'] = "pending";
                            $data['refno']  = "Transaction under process";
                            $data['remark'] = isset($post->errorMsg) ? $post->errorMsg : "Check status after 1 hour";
                        }

                        if(isset($data['status'])){
                            if($data["status"] == "failed"){
                                    Report::where('txnid', $post->txnid)->update([
                                        "status" => $data['status'],
                                        "refno"  => $data['refno'],
                                        "remark" => $data['remark']
                                    ]);
//                                 $checkSumData = array(            
//                                     "MERCHANTCODE" => "MODISH2022",
//                                     "REQUESTID"    => $report->txnid,
//                                     "SSOTOKEN"     => "0"
//                                 );
//                                 $checkSumData_query = "toBeCheckSumString=".json_encode($checkSumData);

//                                 $header = [
//                                     "cache-control: no-cache",
//                                     "content-type: application/x-www-form-urlencoded"
//                                 ];

//                                 $checkSumurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraMD5Checksum";
//                                 $checkSumcurl = \Myhelper::curl($checkSumurl, "POST", $checkSumData_query, $header, "no");

//                                 if($checkSumcurl["response"] != ""){
//                                     $failedData = array(            
//                                         "MERCHANTCODE" => "MODISH2022",
//                                         "SSOTOKEN"     => "0",
//                                         "REQUESTID"    => $report->txnid,
//                                         "EMITRATOKEN"  => $report->payid,
//                                         "CHECKSUM"     => $checkSumcurl["response"],
//                                         "ENTITYTYPEID" => "2",
//                                         "CANCELREMARK" => $data['remark']
//                                     );

//                                     $header = [
//                                         "cache-control: no-cache",
//                                         "content-type: application/x-www-form-urlencoded"
//                                     ];

//                                     $dataForEncryption = "toBeEncrypt=".json_encode($failedData);

//                                     $encurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESEncryption";
//                                     $enccurl = \Myhelper::curl($encurl, "POST", $dataForEncryption, $header, "no");

//                                     $backToCancleEncryption = "encData=".$enccurl["response"];
//                                     $checkSumurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/backendTransCancelByDepartmentWithEncryption";
//                                     $checkSumcurl = \Myhelper::curl($checkSumurl, "POST", $backToCancleEncryption, $header, "no");
                                
//                                     $dataencData = "toBeDecrypt=" . $checkSumcurl["response"];
//                                     $header = [
//                                         "cache-control: no-cache",
//                                         "content-type: application/x-www-form-urlencoded"
//                                     ];

//                                     $url  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESDecryption";
//                                     $curl = \Myhelper::curl($url, "POST", $dataencData, $header, "no");

//                                     $cancleData = json_decode($curl["response"]);
//                                     if(isset($cancleData->CANCELSTATUS) && $cancleData->CANCELSTATUS == "SUCCESS"){
//                                         Report::where('txnid', $post->txnid)->update([
//                                             "status" => $data['status'],
//                                             "refno"  => $data['refno'],
//                                             "remark" => $data['remark']
//                                         ]);
//                                     }
                               // }
                            }else{
                                Report::where('txnid', $post->txnid)->update([
                                    "status" => $data['status'],
                                    "refno"  => $data['refno'],
                                    "remark" => $data['remark']
                                ]);
                            }
                        }
                    }else{
                        return redirect(url('apply/pancard/new'));
                    }
                }

                $data["encData"] = $post->encData;
                $dataencData = "toBeDecrypt=" . $post->encData;
                $header = [
                    "cache-control: no-cache",
                    "content-type: application/x-www-form-urlencoded"
                ];

                $url  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESDecryption";
                $curl = \Myhelper::curl($url, "POST", $dataencData, $header, "no");

                if($curl["response"] == ""){
                    dd("1", $curl["error"], $curl["response"]);
                }else{
                
                    $charactersencData = json_decode($curl["response"]);
                    $SSOID        = $charactersencData->SSOID;
                    $SERVICEID    = $charactersencData->SERVICEID;
                    $EMSESSIONID  = $charactersencData->EMSESSIONID;
                    $KIOSKCODE    = $charactersencData->KIOSKCODE;
                    $OLDKIOSKCODE = $charactersencData->OLDKIOSKCODE;
                    $DISTRICTCD   = $charactersencData->DISTRICTCD;
                    $TEHSILCD     = $charactersencData->TEHSILCD;
                    $RETURNURL    = $charactersencData->RETURNURL;
                    $EMITRATIMESTAMP = $charactersencData->EMITRATIMESTAMP;
                    $SSOTOKEN = $charactersencData->SSOTOKEN;
                    $CHECKSUM = $charactersencData->CHECKSUM;
                    
                    $data['SSOID'] = $SSOID;
                    $data['SERVICEID'] = $SERVICEID;
                    $data['SSOTOKEN'] = $SSOTOKEN;

                    if ($RETURNURL == "") {
                        $RETURNURL = "https://sso.rajasthan.gov.in/pos";
                    }
                    
                    $data['RETURNURL'] = $RETURNURL;

                    $urlverify ="http://sso.rajasthan.gov.in:8888/SSOREST/GetTokenDetail/" . $SSOTOKEN;
                    $curlverify = \Myhelper::curl($urlverify, "GET", "", [], "no", "none", "none", "8888");
                    
                    if($curlverify["response"] == ""){
                        dd("2", $curlverify["error"], $curlverify["response"]);
                    }

                    $datagetKioskDetailsJSON = "MERCHANTCODE=MODISH2022&SSOID=" . $SSOID;
                    $kioskurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/getKioskDetailsJSON";
                    $kioskcurl = \Myhelper::curl($kioskurl, "POST", $datagetKioskDetailsJSON, $header, "no");

                    if($kioskcurl["response"] == ""){
                        dd("3", $kioskcurl["error"], $kioskcurl["response"]);
                    }else{
                        $charactersgetKioskDetailsJSON = json_decode($kioskcurl["response"]);
                        $REQUESTTIMESTAMPJ  = $charactersgetKioskDetailsJSON->REQUESTTIMESTAMP;
                        $REQUESTSTATUSCODEJ = $charactersgetKioskDetailsJSON->REQUESTSTATUSCODE;
                        $MSGJ   = $charactersgetKioskDetailsJSON->MSG;
                        $SSOIDJ = $charactersgetKioskDetailsJSON->SSOID;
                        $MERCHANTCODEJ = $charactersgetKioskDetailsJSON->MERCHANTCODE;
                        $KIOSKCODEJ    = $charactersgetKioskDetailsJSON->KIOSKCODE;
                        $OLDKIOSKCODEJ = $charactersgetKioskDetailsJSON->OLDKIOSKCODE;
                        $KIOSKNAMEJ    = $charactersgetKioskDetailsJSON->KIOSKNAME;
                        $ENTITYTYPEJ   = $charactersgetKioskDetailsJSON->ENTITYTYPE;
                        $DISTRICTJ     = $charactersgetKioskDetailsJSON->DISTRICT;
                        $DISTRICTCDJ   = $charactersgetKioskDetailsJSON->DISTRICTCD;
                        $TEHSILJ       = $charactersgetKioskDetailsJSON->TEHSIL;
                        $TEHSILCDJ     = $charactersgetKioskDetailsJSON->TEHSILCD;
                        $VILLAGEJ      = $charactersgetKioskDetailsJSON->VILLAGE;
                        $VILLAGECDJ    = $charactersgetKioskDetailsJSON->VILLAGECD;
                        $WARDJ         = $charactersgetKioskDetailsJSON->WARD;
                        $WARDCDJ       = $charactersgetKioskDetailsJSON->WARDCD;
                        $PINCODEJ      = $charactersgetKioskDetailsJSON->PINCODE;
                        $MOBILEJ       = $charactersgetKioskDetailsJSON->MOBILE;
                        $EMAILJ        = $charactersgetKioskDetailsJSON->EMAIL;
                        $KIOSK_ADMINJ  = $charactersgetKioskDetailsJSON->KIOSK_ADMIN;
                        $LSPNAMEJ = $charactersgetKioskDetailsJSON->LSPNAME;
                        $LSPCODEJ = $charactersgetKioskDetailsJSON->LSPCODE;
                        $EMITRATIMESTAMPJ = $charactersgetKioskDetailsJSON->EMITRATIMESTAMP;
                        
                        $data['KIOSKNAMEJ'] = $KIOSKNAMEJ;
                        $data['KIOSKCODEJ'] = $KIOSKCODEJ;
                        $data['KIOSKDATA']  = $kioskcurl["response"];
                    }
                }
                
                if($product == "nsdl"){
                    return view('apply.nsdlaccount')->with($data);
                }else{
                    return view('apply.nsdlpancard')->with($data);
                }
                break;
        }
    }

    public function panApplyProcess(Request $post)
    {
        $rules = array(
            'lastname' => 'required',
            'description' => 'required',
            'title'    => 'required',
            'mobile'   => 'required',
            'email'    => 'required',
            "consent"  => "required",
            "option2"  => "required",
        );
        
        $validator = \Validator::make($post->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['errors'=>$validator->errors()], 422);
        }

        $newTime = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s")." -10 minutes"));
        $today   = date('YmdHisU');
        $today2  = date('ymdHis');
        $mtime   = substr($today,0,-7);

        do {
            $partOne = substr(str_shuffle("ABCDEFGHJKLMNPQRSTUVWXYZ"), 0, 2);    
            $partTwo = substr(str_shuffle("0123456789"), 0, 3);  
            $pref    = "R";
            $post["txnid"] = $pref.$today2.$partOne.$partTwo;
        } while (Report::where("txnid", "=", $post->txnid)->first() instanceof Report);

        $checkSumData = array(            
            "SSOID"     => $post->SSOID,
            "REQUESTID" => $post->txnid,
            "REQTIMESTAMP" => $mtime,
            "SSOTOKEN"  => $post->SSOTOKEN
        );
        $checkSumData_query = "toBeCheckSumString=".json_encode($checkSumData);

        $header = [
            "cache-control: no-cache",
            "content-type: application/x-www-form-urlencoded"
        ];

        $checkSumurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraMD5Checksum";
        $checkSumcurl = \Myhelper::curl($checkSumurl, "POST", $checkSumData_query, $header, "no");

        if($checkSumcurl["error"] || $checkSumcurl["response"] == ""){
            return response()->json(['status' => 'ERR', 'message' => 'Something went wrong, try again']);
        }

        $reven = "3206-107.00|3207-10.00";
        $databacktobackenc = array(            
            "MERCHANTCODE" => "MODISH2022",
            "REQTIMESTAMP" => $mtime,
            "SUBSERVICEID" => "",
            "REVENUEHEAD"  => $reven,
            "CONSUMERKEY"  => $post->txnid,
            "OFFICECODE"   => "MODISHHQ",
            "CONSUMERNAME" => $post->firstname." ".$post->middlename." ".$post->lastname,
            "COMMTYPE"     => "3",
            "SSOTOKEN"     => $post->SSOTOKEN,
            "REQUESTID"    => $post->txnid,
            "SSOID"        => $post->SSOID,
            "SERVICEID"    => $post->SERVICEID,
            "CHECKSUM"     => $checkSumcurl["response"],
        );
        
        $dataForEncryption = "toBeEncrypt=".json_encode($databacktobackenc);

        $encurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESEncryption";
        $enccurl = \Myhelper::curl($encurl, "POST", $dataForEncryption, $header, "no");

        if($enccurl["error"] || $enccurl["response"] == ""){
            return response()->json(['status' => 'ERR', 'message' => $enccurl["error"]."/".$enccurl["response"]]);
        }

        $backTobackEncryption = "encData=".$enccurl["response"];

        $backencurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/backtobackTransactionWithEncryptionA";
        $backenccurl = \Myhelper::curl($backencurl, "POST", $backTobackEncryption, $header, "no");

        if($backenccurl["error"] || $backenccurl["response"] == ""){
            return response()->json(['status' => 'ERR', 'message' => 'Something went wrong, try again']);
        }

        $datchecksumencbacktobackTransaction ="toBeDecrypt=".$backenccurl["response"];

        $backencdecurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESDecryption";
        $backencdeccurl = \Myhelper::curl($backencdecurl, "POST", $datchecksumencbacktobackTransaction, $header, "no");
        
        //dd(json_encode($databacktobackenc), $backencdeccurl);
        if($backencdeccurl["error"] || $backencdeccurl["response"] == ""){
            return response()->json(['status' => 'ERR', 'message' => 'Something went wrong, try again']);
        }

        $charactersencDataTransaction = json_decode($backencdeccurl["response"]);
        $REQUESTID             = $charactersencDataTransaction->REQUESTID;
        $TRANSACTIONSTATUSCODE = $charactersencDataTransaction->TRANSACTIONSTATUSCODE;
        $RECEIPTNO             = $charactersencDataTransaction->RECEIPTNO;
                   
        $TRANSACTIONID     = $charactersencDataTransaction->TRANSACTIONID;
        $TRANSAMT          = $charactersencDataTransaction->TRANSAMT;
        $REMAININGWALLET   = $charactersencDataTransaction->REMAININGWALLET;
        $MSG               = $charactersencDataTransaction->MSG;
        $TRANSACTIONSTATUS = $charactersencDataTransaction->TRANSACTIONSTATUS;
     
        $CHECKSUMf = $charactersencDataTransaction->CHECKSUM;

        if($TRANSACTIONSTATUSCODE != "200" || $TRANSACTIONSTATUS != "SUCCESS"){
            return response()->json(['status' => 'ERR', 'message' => 'Something went wrong, try again']);
        }
        
        try{
            $provider = Provider::where('recharge1', 'pancard')->first();
            $insert = [
                'number'  => $post->mobile,
                'mobile'  => $post->mobile,
                'provider_id' => $provider->id,
                'api_id'  => $provider->api->id,
                'amount'  => 107,
                'txnid'   => $post->txnid,
                'payid'   => $TRANSACTIONID,
                'option1' => $post->option1,
                'option2' => $post->option2,
                'option3' => $post->KIOSKCODEJ,
                'option4' => $post->firstname." ".$post->middlename." ".$post->lastname,
                'option5' => $post->email,
                'option6' => $post->category,
                'option7' => $post->pancard,
                "option8" => $post->description,
                "option9" => $post->SSOTOKEN,
                "option10"=> $post->KIOSKDATA,
                'description' => $post->encData,
                'status'  => 'pending',
                'user_id'    => 1,
                'credit_by'  => 1,
                'rtype'      => 'main',
                'balance'    => "0",
                'trans_type' => 'none',
                'product'    => 'directpancard',
                'create_time'=> $post->mobile."-".date('ymdhis')
            ];
    
            $report = Report::create($insert);
            $formData = array(
                "applicantDto" => array(
                    "appliType" => $post->option1,
                    "category"  => $post->category,
                    "title"     => $post->title,
                    "lastName"  => $post->lastname,
                    "firstName" => $post->firstname,
                    "middleName"=> $post->middlename,  
                    "applnMode" => $post->description,
                ),
                "otherDetails"  => array(
                    "phyPanIsReq" => "Y",
                ),
                "telOrMobNo" => $post->mobile, 
            );
    
            if($post->category == "CR"){
                $formData["applicantDto"]["pan"] = $post->pancard;
            }
    
            $parameterData = array(
                "reqEntityData"=> array(
                    "txnid"           => $post->txnid,
                    "branchCode"      => $post->SSOID,
                    "entityId"        => "AchariyaTechno",
                    "dscProvider"     => "Verasys CA 2014",
                    "dscSerialNumber" => "2B 32 60 77",
                    "dscExpiryDate"   => "4-3-24",
                    "returnUrl" => url("apply/pan/".$post->type),
                    "formData"  => base64_encode(json_encode($formData)),
                    "reqTs"     => date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s")." -10 minutes")),
                    "authKey"   => "AchariyaTechno",
                ),
                "signature"=>""
            );
    
            if($post->category == "A"){
                $type = "F";
            }else{
                $type = "C";
                $parameterData["reqEntityData"]["reqType"] = "CR";
            }
            
            // $pfxfile  = "/home/rajpay/public_html/YESPAL.pfx";
            // $jarfile  = "/home/rajpay/public_html/Assissted_Signing_v3.jar";
            // $filedata = "$jarfile ".base64_encode(json_encode($parameterData))." $pfxfile 123456789 YESPAL ".$type;
            // $page = shell_exec("java -jar $filedata");
            $url = "https://admin.e-banker.in/api/nsdl/signature?type=".$type."&data=".base64_encode(json_encode($parameterData));
            $signature = \Myhelper::curl($url, "POST", "", [], "no");
            
            if($post->category == "A"){
                $data = substr(json_decode(json_encode($signature["response"]), true), 38);
            }else{
                $data = substr(json_decode(json_encode($signature["response"]), true), 43);
            }
            
            $query["req"] = $data;
            return response()->json(['statuscode' => "TXN", "data" => $query["req"], "panData" => $formData, "requestData" => $data, "signature" => $signature["response"]]);
        } catch (\Exception $e) {
            $checkSumData = array(            
                "MERCHANTCODE" => "MODISH2022",
                "REQUESTID"    => $post->txnid,
                "SSOTOKEN"     => "0"
            );
            $checkSumData_query = "toBeCheckSumString=".json_encode($checkSumData);

            $header = [
                "cache-control: no-cache",
                "content-type: application/x-www-form-urlencoded"
            ];

            $checkSumurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraMD5Checksum";
            $checkSumcurl = \Myhelper::curl($checkSumurl, "POST", $checkSumData_query, $header, "no");

            if($checkSumcurl["response"] != ""){
                $failedData = array(            
                    "MERCHANTCODE" => "MODISH2022",
                    "SSOTOKEN"     => "0",
                    "REQUESTID"    => $post->txnid,
                    "EMITRATOKEN"  => $post->txnid,
                    "CHECKSUM"     => $checkSumcurl["response"],
                    "ENTITYTYPEID" => "2",
                    "CANCELREMARK" => "Timeout"
                );

                $header = [
                    "cache-control: no-cache",
                    "content-type: application/x-www-form-urlencoded"
                ];

                $dataForEncryption = "toBeEncrypt=".json_encode($failedData);

                $encurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESEncryption";
                $enccurl = \Myhelper::curl($encurl, "POST", $dataForEncryption, $header, "no");

                $backToCancleEncryption = "encData=".$enccurl["response"];
                $checkSumurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/backendTransCancelByDepartmentWithEncryption";
                $checkSumcurl = \Myhelper::curl($checkSumurl, "POST", $backToCancleEncryption, $header, "no");
            
                $dataencData = "toBeDecrypt=" . $checkSumcurl["response"];
                $header = [
                    "cache-control: no-cache",
                    "content-type: application/x-www-form-urlencoded"
                ];

                $url  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESDecryption";
                $curl = \Myhelper::curl($url, "POST", $dataencData, $header, "no");

                $cancleData = json_decode($curl["response"]);
                
                \DB::table('log_500')->insert([
                    'line' => json_encode($checkSumData)."/".json_encode($failedData),
                    'file' => $e->getFile(),
                    'log'  => $curl["response"].$e->getMessage(),
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                return response()->json(['statuscode' => "ERR", "message" => "Something went wrong"]);
            }
        }
    }

    public function panStatusProcess(Request $post)
    {
        $rules = array(
            'txnid' => 'required'
        );
        
        $validator = \Validator::make($post->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['errors'=>$validator->errors()], 422);
        }

        $today = date('YmdH');
        $partOne =  substr(str_shuffle("ABCDEFGHJKLMNPQRSTUVWXYZ"), 0, 2);    
        $partTwo =  substr(str_shuffle("0123456789"), 0, 3);  
        $rpid    = $today.$partOne.$partTwo;

        $parameterData = array(
            "panReqEntityData"=> array(
                //"txnid"           => "230574006443",
                "txnid"           => $rpid,
                "ackNo"           => $post->txnid,
                "entityId"        => "AchariyaTechno",
                "dscProvider"     => "Verasys CA 2014",
                "dscSerialNumber" => "2B 32 60 77",
                "dscExpiryDate"   => "4-3-24",
                "returnUrl" => url("callback/nsdlpan"),
                "reqTs"     => date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s")." -10 minutes")),
                "authKey"   => "AchariyaTechno",
            ),
            "signature"=>""
        );
        
        $url = "https://admin.e-banker.in/api/nsdl/signature?type=S&data=".base64_encode(json_encode($parameterData));
        $signature = \Myhelper::curl($url, "POST", "", [], "no");
        $data      = substr(json_decode(json_encode($signature["response"]), true), 45);

        $url = "https://assisted-service.egov-nsdl.com/SpringBootFormHandling/PanStatusReq";
        $response = \Myhelper::curl($url, "POST", $data, array(
            "cache-control: no-cache",
            "content-type: application/json",
            "postman-token: 9a6f7632-b4ea-78f1-c393-12a31b12316a"
          ), "no");

        $pandata = json_decode($response["response"]);

        if(isset($pandata->panStatus)){
            return response()->json(['statuscode' => "TXN", "message" => $pandata->panStatus]);
        }else{
            return response()->json(['statuscode' => "ERR", "message" => isset($pandata->error) ? json_encode($pandata->error) : "Something went wrong"]);
        }
    }

    public function txnStatusProcess(Request $post)
    {
        $rules = array(
            'txnid' => 'required'
        );
        
        $validator = \Validator::make($post->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['errors'=>$validator->errors()], 422);
        }

        $parameterData = array(
            "txnReqEntityData"=> array(
                "request_type"    => "T",
                "txn_id"          => $post->txnid,
                "unique_txn_id"   => $post->txnid,
                "date"            => "",
                "entity_Id"       => "AchariyaTechno",
                "dscProvider"     => "Verasys CA 2014",
                "dscSerialNumber" => "2B 32 60 77",
                "dscExpiryDate"   => "4-3-24",
                "returnUrl" => url("callback/nsdlpan"),
                "reqTs"     => date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s")." -10 minutes")),
                "authKey"   => "AchariyaTechno",
            ),
            "signature"=>""
        );

        $url = "https://admin.e-banker.in/api/nsdl/signature?type=T&data=".base64_encode(json_encode($parameterData));
        $signature = \Myhelper::curl($url, "POST", "", [], "no");
        $data      = substr(json_decode(json_encode($signature["response"]), true), 52);

        $url = "https://assisted-service.egov-nsdl.com/SpringBootFormHandling/checkTransactionStatus";
        $response = \Myhelper::curl($url, "POST", $data, array(
            "cache-control: no-cache",
            "content-type: application/json",
            "postman-token: 9a6f7632-b4ea-78f1-c393-12a31b12316a"
          ), "no");

        $pandata = json_decode($response["response"]);
        if(isset($pandata->status) && $pandata->status == "success"){
            return response()->json(['statuscode' => "TXN", "message" => "Your acknowledgement number is ".$pandata->ack_No]);
        }elseif(isset($pandata->error) && $pandata->error != null){
            return response()->json(['statuscode' => "ERR", "message" => isset($pandata->error) ? json_encode($pandata->error) : "Something went wrong"]);
        }else{
            return response()->json(['statuscode' => "ERR", "message" => isset($pandata->errordesc) ? $pandata->errordesc : "Something went wrong"]);
        }
    }

    public function panreport(Request $request)
    {
        if(!$request->has("fromdate") || empty($request->fromdate) || $request->fromdate == NULL || $request->fromdate == "null" ){
            $request['fromdate'] = date("Y-m-d");
        }

        if(!$request->has("todate") || empty($request->todate) || $request->todate == NULL || $request->todate == "null" ){
            $request['todate'] = $request->fromdate;
        }

        $query  = \DB::table("reports")
            ->orderBy('id', 'desc')
            ->where('rtype', "main")
            ->where('option3', $request->agent)
            ->where('product', 'directpancard');

        if(!empty($request->searchtext)){
            $serachDatas = ['txnid', 'refno'];
            $query->where( function($q) use($request, $serachDatas){
                foreach ($serachDatas as $value) {
                    $q->orWhere($value , 'like', '%'.$request->searchtext.'%');
                }
            });
            $dateFilter = 0;
        }

        if(isset($request->status) && $request->status != '' && $request->status != null){
            $query->where('status', $request->status);
            $dateFilter = 0;
        }

        $query->whereBetween('created_at', [Carbon::createFromFormat('Y-m-d', $request->fromdate)->format('Y-m-d'), Carbon::createFromFormat('Y-m-d', $request->todate)->addDay(1)->format('Y-m-d')]);

        $selects = ['id','mobile' ,'number', 'txnid', 'amount', 'profit', 'charge','tds', 'gst', 'payid', 'refno', 'balance', 'status', 'rtype', 'trans_type', 'user_id', 'credit_by', 'created_at', 'product','option1', 'option3', 'option2', 'option5', 'option4','option6', 'option7', 'option8', 'option10', 'description','remark'];

        $selectData = [];
        foreach ($selects as $select) {
            $selectData[] = $select;
        }

        $exportData = $query->select($selectData);  
        $count = intval($exportData->count());

        if(isset($request['length']) && $request->length != "-1"){
            $exportData->skip($request['start'])->take($request['length']);
        }

        $data = array(
            "draw"            => intval($request['draw']),
            "recordsTotal"    => $count,
            "recordsFiltered" => $count,
            "data"            => $exportData->get()
        );
        echo json_encode($data);
    }

    public function accountNsdlProcess(Request $post)
    {
        $rules = array(
            'Customername' => 'required',
            'Email'    => 'required',
            'mobileNo' => 'required',
            'panNo'    => 'required'
        );
        
        $validator = \Validator::make($post->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['errors'=>$validator->errors()], 422);
        }
        
        $post["name"]   = $post->Customername;
        $post["email"]  = $post->Email;
        $post["mobile"] = $post->mobileNo;
        $post["user_id"] = 0;
        $post["type"] = "nsdl";
        
        $newTime = date("Y-m-d H:i:s",strtotime(date("Y-m-d H:i:s")." -10 minutes"));
        $today   = date('YmdHisU');
        $today2  = date('ymdHis');
        $mtime   = substr($today,0,-7);

        do {
            $partOne = substr(str_shuffle("ABCDEFGHJKLMNPQRSTUVWXYZ"), 0, 2);    
            $partTwo = substr(str_shuffle("0123456789"), 0, 3);  
            $pref    = "R";
            $post["txnid"] = $pref.$today2.$partOne.$partTwo;
        } while (Report::where("txnid", "=", $post->txnid)->first() instanceof Report);

        $checkSumData = array(            
            "SSOID"     => $post->SSOID,
            "REQUESTID" => $post->txnid,
            "REQTIMESTAMP" => $mtime,
            "SSOTOKEN"  => $post->SSOTOKEN
        );
        $checkSumData_query = "toBeCheckSumString=".json_encode($checkSumData);

        $header = [
            "cache-control: no-cache",
            "content-type: application/x-www-form-urlencoded"
        ];

        $checkSumurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraMD5Checksum";
        $checkSumcurl = \Myhelper::curl($checkSumurl, "POST", $checkSumData_query, $header, "no");
        
        if($checkSumcurl["error"] || $checkSumcurl["response"] == ""){
            return response()->json(['status' => 'ERR', 'message' => 'Something went wrong, try again']);
        }
        
        $reven =  "3206-120.00|3207-20.00";
        
        $databacktobackenc = array(            
            "MERCHANTCODE" => "MODISH2022",
            "REQTIMESTAMP" => $mtime,
            "SUBSERVICEID" => "",
            "REVENUEHEAD"  => $reven,
            "CONSUMERKEY"  => $post->txnid,
            "OFFICECODE"   => "MODISHHQ",
            "CONSUMERNAME" => $post->firstname." ".$post->middlename." ".$post->lastname,
            "COMMTYPE"     => "3",
            "SSOTOKEN"     => $post->SSOTOKEN,
            "REQUESTID"    => $post->txnid,
            "SSOID"        => $post->SSOID,
            "SERVICEID"    => $post->SERVICEID,
            "CHECKSUM"     => $checkSumcurl["response"],
        );
        
        $dataForEncryption = "toBeEncrypt=".json_encode($databacktobackenc);

        $encurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESEncryption";
        $enccurl = \Myhelper::curl($encurl, "POST", $dataForEncryption, $header, "no");

        if($enccurl["error"] || $enccurl["response"] == ""){
            return response()->json(['status' => 'ERR', 'message' => $enccurl["error"]."/".$enccurl["response"]]);
        }

        $backTobackEncryption = "encData=".$enccurl["response"];

        $backencurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/backtobackTransactionWithEncryptionA";
        $backenccurl = \Myhelper::curl($backencurl, "POST", $backTobackEncryption, $header, "no");

        if($backenccurl["error"] || $backenccurl["response"] == ""){
            return response()->json(['status' => 'ERR', 'message' => 'Something went wrong, try again']);
        }

        $datchecksumencbacktobackTransaction ="toBeDecrypt=".$backenccurl["response"];

        $backencdecurl  = "https://emitraapp.rajasthan.gov.in/webServicesRepository/emitraAESDecryption";
        $backencdeccurl = \Myhelper::curl($backencdecurl, "POST", $datchecksumencbacktobackTransaction, $header, "no");
        
        // dd($databacktobackenc, $backencdecurl, $backencdeccurl, $datchecksumencbacktobackTransaction, $header, $checkSumcurl);
        if($backencdeccurl["error"] || $backencdeccurl["response"] == ""){
            return response()->json(['status' => 'ERR', 'message' => 'Something went wrong, try again']);
        }

        $charactersencDataTransaction = json_decode($backencdeccurl["response"]);
        
        // dd($checkSumData, $checkSumData_query,$checkSumcurl, $header,$databacktobackenc, $encurl, $enccurl, $charactersencDataTransaction);
        $REQUESTID             = $charactersencDataTransaction->REQUESTID;
        $TRANSACTIONSTATUSCODE = $charactersencDataTransaction->TRANSACTIONSTATUSCODE;
        $RECEIPTNO             = $charactersencDataTransaction->RECEIPTNO;
                   
        $TRANSACTIONID     = $charactersencDataTransaction->TRANSACTIONID;
        $TRANSAMT          = $charactersencDataTransaction->TRANSAMT;
        $REMAININGWALLET   = $charactersencDataTransaction->REMAININGWALLET;
        $MSG               = $charactersencDataTransaction->MSG;
        $TRANSACTIONSTATUS = $charactersencDataTransaction->TRANSACTIONSTATUS;
     
        $CHECKSUMf = $charactersencDataTransaction->CHECKSUM;

        if($TRANSACTIONSTATUSCODE != "200" || $TRANSACTIONSTATUS != "SUCCESS"){
            return response()->json(['status' => 'ERR', 'message' => 'Something went wrong, try again']);
        }
        
        // dd($charactersencDataTransaction, $checkSumData, $databacktobackenc, $datchecksumencbacktobackTransaction);
        
        $provider = Provider::where('recharge1', 'nsdlpaymentbank')->first();
        $insert = [
            'number'  => $post->mobile,
            'mobile'  => $post->mobile,
            'provider_id' => $provider->id,
            'api_id'  => $provider->api->id,
            'amount'  => 120,
            'txnid'   => $post->txnid,
            'payid'   => $TRANSACTIONID,
            'option1' => $post->name,
            'option3' => $post->KIOSKCODEJ,
            'option5' => $post->email,
            'option7' => $post->panNo,
            "option9" => $post->SSOTOKEN,
            "option10"=> $post->KIOSKDATA,
            'description' => $post->encData,
            'status'  => 'pending',
            'user_id'    => $post->user_id,
            'credit_by'  => 1,
            'rtype'      => 'main',
            'balance'    => "0",
            'trans_type' => 'none',
            'product'    => $post->type,
            'create_time'=> $post->mobile."-".date('ymdhis')
        ];

        $action  = Report::create($insert);
        
        if ($action) {
            $checksumStringCheck = "pin|nomineeName|nomineeDob|relationship|add2|add1|nomineeState|nomineeCity|add3|dateofbirth|pincode|customerLastName|mobileNo|customername|email|partnerRefNumber|clientid|dpid|customerDematId|bcid|applicationdocketnumber|tradingaccountnumber|bcagentid|customerRefNumber|partnerpan|partnerid|channelid|partnerCallBackURL|income|middleNameOfMother|panNo|kycFlag|maritalStatus|houseOfFatherOrSpouse";
            $name = explode(" ", $post->name);

            $jsonbody = '{
                "nomineeName": "",
                "nomineeDob": "",
                "relationship": "",
                "add1": "",
                "add2": "",
                "add3": "",
                "pin": "",
                "nomineeState": "",
                "nomineeCity": "",
                "customername": "",
                "customerLastName": "",
                "dateofbirth": "",
                "pincode": "",
                "email": "'.$post->email.'",
                "mobileNo": "'.$post->mobileNo.'",
                "maritalStatus": "",
                "income": "",
                "middleNameOfMother": "",
                "houseOfFatherOrSpouse": "",
                "kycFlag": "",
                "panNo": "'.$post->panNo.'",
                "channelid": "GpuqFObVfGrMfbtATuTY",
                "partnerid": "xZ5W1JJbNV",
                "applicationdocketnumber": "",
                "dpid": "",
                "clientid": "",
                "partnerpan": "BPEPS0424L",
                "tradingaccountnumber": "",
                "partnerRefNumber": "",
                "customerRefNumber": "",
                "customerDematId": "",
                "partnerCallBackURL": "https://rajpay.in/apply/nsdl/saving_account",
                "bcid": "3653",
                "bcagentid": "ACH0001"
            }';

            $body = '{"nomineeDetails":{"nomineeName": "","nomineeDob": "","relationship": "","add1": "","add2": "","add3": "","pin": "","nomineeState": "","nomineeCity": ""},"personalDetails":{"customername": "","customerLastName": "","dateofbirth": "","pincode": "","email": "'.$post->email.'","mobileNo": "'.$post->mobileNo.'"},"otherDeatils":{"maritalStatus": "","income": "","middleNameOfMother": "","houseOfFatherOrSpouse": "","kycFlag": "","panNo": "'.$post->panNo.'"},"additionalParameters":{"channelid": "GpuqFObVfGrMfbtATuTY","partnerid": "xZ5W1JJbNV","applicationdocketnumber": "","dpid": "","clientid": "","partnerpan": "BPEPS0424L","tradingaccountnumber": "","partnerRefNumber": "","customerRefNumber": "","customerDematId": "","partnerCallBackURL": "https://rajpay.in/apply/nsdl/saving_account","bcid": "3653","bcagentid": "ACH0001"}}';

            $arraybody = json_decode($jsonbody, true);
            $checksumStringCheckArray = explode("|", $checksumStringCheck);
            $checksumString = "";
            foreach ($checksumStringCheckArray as $key => $value) {
                $checksumString .= $arraybody[$value];
            }

            $fkey="UBBluRkIcEyhPpVEpokWUvrAnykxvweUDVeUgArMJKWBUSKUTVnzDNTHzmipOPcgacCvpNQzyHXoOCUGTYwyKybCIMKvPUsjnZxKgbTRcLoRPoNSKeoYNDiipMqFiJjl";
            $signcs = base64_encode(hash_hmac('sha512', $checksumString, $fkey, true));

            $key= "UBBluRkIcEyhPpVE";
            $iv = "UBBluRkIcEyhPpVE";
            $encrypted = openssl_encrypt($body, 'aes-128-cbc', $key, 0, $iv);
            return response()->json(["statuscode" => "TXN", "message" => "https://nsdljiffy.co.in/jarvisjiffyBroker/accountOpen?partnerid=xZ5W1JJbNV&signcs=".$signcs."&encryptedStringCustomer=".urlencode($encrypted)]);
        }else{
            return response()->json(['statuscode' => "ERR", "message" => "Task Failed, please try again"]);
        }
    }
    
    public function nsdlreport(Request $request)
    {
        if(!$request->has("fromdate") || empty($request->fromdate) || $request->fromdate == NULL || $request->fromdate == "null" ){
            $request['fromdate'] = date("Y-m-d");
        }

        if(!$request->has("todate") || empty($request->todate) || $request->todate == NULL || $request->todate == "null" ){
            $request['todate'] = $request->fromdate;
        }

        $query  = \DB::table("reports")
            ->orderBy('id', 'desc')
            ->where('rtype', "main")
            ->where('option3', $request->agent)
            ->where('product', 'nsdl');

        if(!empty($request->searchtext)){
            $serachDatas = ['txnid', 'refno'];
            $query->where( function($q) use($request, $serachDatas, $tables){
                foreach ($serachDatas as $value) {
                    $q->orWhere($value , 'like', '%'.$request->searchtext.'%');
                }
            });
            $dateFilter = 0;
        }

        if(isset($request->status) && $request->status != '' && $request->status != null){
            $query->where('status', $request->status);
            $dateFilter = 0;
        }

        $query->whereBetween('created_at', [Carbon::createFromFormat('Y-m-d', $request->fromdate)->format('Y-m-d'), Carbon::createFromFormat('Y-m-d', $request->todate)->addDay(1)->format('Y-m-d')]);

        $selects = ['id','mobile' ,'number', 'txnid', 'amount', 'profit', 'charge','tds', 'gst', 'payid', 'refno', 'balance', 'status', 'rtype', 'trans_type', 'user_id', 'credit_by', 'created_at', 'product','option1', 'option3', 'option2', 'option5', 'option4','option6', 'option7', 'option8', 'option10', 'description','remark'];

        $selectData = [];
        foreach ($selects as $select) {
            $selectData[] = $select;
        }

        $exportData = $query->select($selectData);  
        $count = intval($exportData->count());

        if(isset($request['length']) && $request->length != "-1"){
            $exportData->skip($request['start'])->take($request['length']);
        }

        $data = array(
            "draw"            => intval($request['draw']),
            "recordsTotal"    => $count,
            "recordsFiltered" => $count,
            "data"            => $exportData->get()
        );
        echo json_encode($data);
    }
}
