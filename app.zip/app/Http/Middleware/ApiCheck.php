<?php

namespace App\Http\Middleware;

use Closure;

class ApiCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($post, Closure $next)
    {
        if(!$post->has('token')){
            return response()->json(['statuscode'=>'ERR', 'message'=> 'Invalid api token']);
        }
        
        $user = \App\Model\Apitoken::where('ip', $post->ip())->where('token', $post->token)->first();
        if(!$user){
            return response()->json(['statuscode'=>'ERR','status'=>'ERR','message'=> 'Request From Invalid Ip Address']);
        }

        if($user->status == "0"){
            return response()->json(['statuscode'=>'ERR','status'=>'ERR','message'=> 'Ip Address approval is pending, kindly contact service provider']);
        }

        $post['via'] = "api";
        $post['user_id'] = $user->user_id;
        if(!$post->has("lat")){
            $ip = geoip($post->ip());
            $post['lat'] = sprintf('%0.4f', $ip->lat);
            $post['lon'] = sprintf('%0.4f', $ip->lon);
        }
        return $next($post);
    }
}
