<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Aepsbank extends Model
{
    protected $fillable = ['bankName','iinno', 'aadharpay'];

}
