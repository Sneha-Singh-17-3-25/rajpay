<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Pindata extends Model
{
	protected $fillable = ['pin','user_id'];
}
