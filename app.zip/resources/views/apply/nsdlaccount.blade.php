@extends('layouts.offline')
@section('title', $KIOSKCODEJ)
@section('name', $KIOSKNAMEJ)

@section('content')
    <div class="content">
        <div class="tabbable">
            <ul class="nav nav-tabs bg-teal-600 nav-tabs-component no-margin-bottom">
                <li><a href="#openaccount" data-toggle="tab" id="reportTab" class="legitRipple active" aria-expanded="true"><i class="icon-plus22"></i> Open Account</a></li>
                <li><a href="#reoprt" data-toggle="tab" id="reportTab" class="legitRipple" aria-expanded="false"><i class="icon-file-text3"></i> Report</a></li>
            </ul>
            
            <div class="tab-content pt-20">
                <div class="tab-pane active" id="openaccount">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="panel panel-default panel-shadow">
                                <div class="panel-heading">
                                    <h5 class="panel-title"><img src="{{asset('assets/images/balance.png')}}" width="40px"/>Open Saving Account  -</h5>
                                </div>
                                <form action="{{ route('accountNsdlProcess') }}" method="post" id="transactionForm">
                                    <input type="hidden" name="SSOID" value="{{$SSOID}}">
                                    <input type="hidden" name="SERVICEID"  value="{{$SERVICEID}}">
                                    <input type="hidden" name="SSOTOKEN"   value="{{$SSOTOKEN}}">
                                    <input type="hidden" name="RETURNURL"  value="{{$RETURNURL}}">
                                    <input type="hidden" name="KIOSKNAMEJ" value="{{$KIOSKNAMEJ}}">
                                    <input type="hidden" name="KIOSKCODEJ" value="{{$KIOSKCODEJ}}">
                                    <input type="hidden" name="KIOSKDATA"  value="{{$KIOSKDATA}}">
                                    <input type="hidden" name="encData"  value="{{$encData}}">
                                    {{ csrf_field() }}
    
                                    <div class="panel-body">
                                        <div class="form-group">
                                            <label for="Customername">Name</label>
                                            <input type="text" class="form-control" id="name" name="Customername"
                                                placeholder="Enter name" required>
                                        </div>
    
                                        <div class="form-group">
                                            <label for="mobileNo">Mobile</label>
                                            <input type="text" class="form-control" id="mobile" name="mobileNo"
                                                pattern="[0-9]*" maxlength="10" minlength="10" placeholder="Enter mobile number"
                                                required>
                                        </div>
    
                                        <div class="form-group">
                                            <label for="Email">Email</label>
                                            <input type="email" class="form-control" id="Email" name="Email"
                                                placeholder="Enter email" required>
                                        </div>
    
                                        <div class="form-group">
                                            <label for="panNo">PAN Number</label>
                                            <input type="text" class="form-control" id="panNo" name="panNo"
                                                placeholder="Enter pan" required>
                                        </div>
                                    </div>
    
                                    <div class="panel-footer text-center">
                                        <button type="submit" class="btn bg-teal-800 btn-labeled legitRipple btn-lg" onclick="return confirm('Are you sure you want to process this transaction?')"
                                            data-loading-text="<b><i class='fa fa-spin fa-spinner'></i></b> Submitting">
                                            <b><i class="icon-paperplane"></i></b> Submit
                                        </button>
                                    </div>
                                </form>
                            </div>
                    </div>
                        
                        <div class="col-md-8">
                            <div>
                                <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 10;" class="ml-paragraph">
                                    <h2><b>NSDL JIFY ZERO BALANCE ACCOUNT</b></h2>
                                    <img src="{{asset('assets/images/logo.png')}}"/>
                                </div>
                                <div style="text-align: center;" class="ml-paragraph">NSDL Jiffy Zero Balance Account is a 100% Digital - Zero Balance savings account that comes with a host of features and benefits.<br>
                                You can open this account with eMitra within a few minutes using just your Aadhar and PAN number.<br>
                                With instant activation of the account, you can enjoy instant fund transfers, utility bill payments,quick recharge, UPI payments, and much more.
                                </div>
                            </div>
                            
                            <div class="justify-content-center text-center">
                                <h2>Key Features</h2>
                            </div>
        
                            <div>
                                <p class="ml-paragraph">- Zero Balance Account (No requirement to maintain Average Monthly Balance)
                                </p>
                                <p class="ml-paragraph">- Free Virtual Debit Card, Choose your free virtual debit card from RuPay or
                                    VISA
                                    for online purchases/shopping.</p>
                                <p class="ml-paragraph">You can request a physical debit card from your NSDL Jiffy App</p>
                                <p class="ml-paragraph">- Instant Account Activation, Activate your account instantly with our 100%
                                    digital, safe and secure account opening process</p>
                                <p class="ml-paragraph">- Bill Payments and Recharges</p>
                                <p class="ml-paragraph">- Banking On Mobile - 24/7</p>
                                <p class="ml-paragraph">Enjoy banking anytime, anywhere from your smartphone with NSDL Jiffy App.,
                                    without
                                    going to the bank branch</p>
                                <p>Account Opening Fee - 120/-</p>
                                <p>eMitra Commission - 20/</p>
                            </div>
                    </div>
                    </div>
                </div>
                
                <div class="tab-pane report" id="reoprt">
                    <div class="panel panel-default">
                        <form id="searchForm">
                            <input type="hidden" name="agent" value="{{$KIOSKCODEJ}}">
                            <div class="panel panel-default no-margin">
                                <div class="panel-body p-tb-10">
                                    <div class="row">
                                        <div class="form-group col-md-2 m-b-10">
                                            <input type="text" name="from_date" class="form-control mydate"
                                                placeholder="From Date">
                                        </div>

                                        <div class="form-group col-md-2 m-b-10">
                                            <input type="text" name="to_date" class="form-control mydate"
                                                placeholder="To Date">
                                        </div>

                                        <div class="form-group col-md-2 m-b-10">
                                            <input type="text" name="searchtext" class="form-control"
                                                placeholder="Search Value">
                                        </div>

                                        @if (isset($status))
                                            <div class="form-group col-md-2">
                                                <select name="status" class="form-control select">
                                                    <option value="">Select {{ $status['type'] ?? '' }} Status
                                                    </option>
                                                    @if (isset($status['data']) && sizeOf($status['data']) > 0)
                                                        @foreach ($status['data'] as $key => $value)
                                                            <option value="{{ $key }}">{{ $value }}
                                                            </option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        @endif

                                        <div class="form-group col-md-4 m-b-10">
                                            <button type="submit" class="btn bg-slate btn-labeled legitRipple mt-5"
                                                data-loading-text="<b><i class='fa fa-spin fa-spinner'></i></b> Searching"><b><i
                                                        class="icon-search4"></i></b> Search</button>

                                            <button type="button" class="btn btn-warning btn-labeled legitRipple mt-5"
                                                id="formReset"
                                                data-loading-text="<b><i class='fa fa-spin fa-spinner'></i></b> Refreshing"><b><i
                                                        class="icon-rotate-ccw3"></i></b> Refresh</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover" id="datatable" width="100%">
                                <thead>
                                    <tr style="white-space: nowrap;">
                                        <th>S.No.</th>
                                        <th>Action</th>
                                        <th>Type</th>
                                        <th>Customer Name</th>
                                        <th>Request ID</th>
                                        <th>Transaction ID</th>
                                        <th>Status</th>
                                        <th>Acknowledge No</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Remark</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div id="receiptModal" class="modal fade" data-backdrop="false" data-keyboard="false">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header bg-slate">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Receipt</h4>
            </div>
            <div class="modal-body">
                <div id="receptTable">
                    <table class="table m-t-10">
                        <thead>
                            <tr>
                                <th style="padding: 10px 0px;">
                                <img src="{{asset('')}}public/{{$mydata['company']->logo}}" class="img-responsive pull-left" alt="" style="height: 60px; width: 260px;">
                                </th>
            					<th style="padding: 10px 0px;">
                                <img src="{{asset('')}}public/logos/t-logo.png" class="img-responsive pull-right" alt="" style="height: 75%; width: 75%;">
            					</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="padding: 10px 0px" class="text-left">
                                    <address class="m-b-10">
										<strong>KIOSK Code : </strong> <span class="p-0">@yield('title')</span><br>
                                        <strong>KIOSK Name : </strong><span class="p-0">@yield('name')</span><br>
                                        <strong>Date : </strong><span class="created_at"></span>
                                    </address>
                                </td>
                                <td style="padding: 10px 0px" class="text-right">
                                    <address class="m-b-10 default">
                                        <strong>Consumer Name : </strong> <span class="option1"></span><br>
                                        <strong>Operator Name : </strong> <span class="product"></span><br>
                                    </address>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <h5>Transaction Details :</h5>
                                <table class="table m-t-10 default">
                                	<thead>
                                		<tr>
                                			<th>Request ID</th>
                                			<th>Ack No</th>
                                		</tr>
                                	</thead>
                                	<tbody>
                                		<tr>
                                			<td class="txnid text-left"></td>
                                			<td class="refno text-left"></td>
                                		</tr>
                                	</tbody>
                                </table>
                                <table class="table m-t-10 default">
                                    <thead>
                                        <tr>
                                            <th>Txn Id</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="payid text-left"></td>
                                            <td class="status text-left"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="border-radius: 0px;">
                        <div class="col-md-6 col-md-offset-6">
                            <h6 class="text-right">Amount : <span class="amount"></span></h6>
                        </div>
                    </div>
                    <hr>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-raised legitRipple" data-dismiss="modal" aria-hidden="true">Close</button>
                <button class="btn bg-slate btn-raised legitRipple" type="button" id="printModal"><i class="fa fa-print"></i></button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('style')
    <style>
        td {
            white-space: nowrap;
            max-width: 100%;
            size: 10px;
            font-size: 13px;
            text-align: center;
        }
        .label {
            font-size: 10px;
         	display: flex;
        }
        
        .content {
            background-image: url("{{asset('assets/images/asia.png')}}");
            background-repeat: no-repeat;
            background-size:100%;
            background-position: bottom center; 
            padding-top: 200px; 
            background-color: rgba(255,255,255,0.6);
            background-blend-mode:hard-light;
        }
        
        .vertical{
            padding:0px !important;
        }
    </style>
@endpush

@push('script')
    <script src="{{ asset('/assets/js/core/jQuery.print.js') }}"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#print').click(function(){
                $('#receipt').find('.modal-body').print();
            });
        
        	$('#printModal').click(function(){
                $('#receiptModal').find('.modal-body').print();
            });
            
            $(window).load(function () {
                @if(isset($status))
                    $("#receipt").modal("show");
                @endif
                
                $("#{{$type}}Tab").click();
            });

            
            $( "#transactionForm" ).validate({
                rules: {
                    name: {
                        required: true
                    },
                    gender: {
                        required: true
                    },
                    mobile: {
                        required: true
                    },
                    email: {
                        required: true
                    }
                },
                messages: {
                    name: {
                        required: "Please enter value"
                    },
                    gender: {
                        required: "Please select value"
                    },
                    mobile: {
                        required: "Please enter value"
                    },
                    email: {
                        required: "Please enter value"
                    },
                },
                errorElement: "p",
                errorPlacement: function ( error, element ) {
                    if ( element.prop("tagName").toLowerCase() === "select" ) {
                        error.insertAfter( element.closest( ".form-group" ).find(".select2") );
                    } else {
                        error.insertAfter( element );
                    }
                },
                submitHandler: function () {
                    var form = $('#transactionForm');
                    SYSTEM.FORMSUBMIT(form, function(data){
                        form[0].reset();
                        form.find('[name="pin"]').val("");
                        if (!data.statusText) {
                            if(data.statuscode == "TXN"){
                                // window.open(data.message, '_blank').focus();
                                window.location.href = data.message;
                            }else if(data.statuscode == "TXF"){
                                $.alert({
                                    title: 'Oops!',
                                    content: data.message,
                                    type: 'red'
                                });
                            }else{
                                $.alert({
                                    title: 'Oops!',
                                    content: data.message,
                                    type: 'red'
                                });
                            }
                        } else {
                            SYSTEM.SHOWERROR(data, form);
                        }
                    });
                }
            });

            $('[name="dataType"]').val("nsdl");
            
            var url = "{{route("nsdlreport")}}";
            
            var onDraw = function() {
                $('.print').click(function(event) {
                var data = DT.row($(this).parent().parent().parent().parent().parent()).data();

                $.each(data, function(index, values) {
                    $("."+index).text(values);
                });
                $('address.dmt').hide();
                $('address.aeps').hide();
                $('address.default').hide();

                if(data['product'] == "dmt"){
                    $('address.dmt').show();
                }else if(data['product'] == "aeps"){
                    $('address.aeps').show();
                }else{
                    $('address.default').show();
                }
                $('#receiptModal').modal();
            });
            };

            var options = [
                { "data" : "id"},            	
                { "data" : "bank",
                 	render:function(data, type, full, meta){
                    var menu = `<li class="dropdown-header">Action</li>`;
                    menu += `<li><a href="javascript:void(0)" class="print"><i class="icon-info22"></i>Print Invoice</a></li>`;

                    return  `<ul class="icons-list mr-5">
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>

                                    <ul class="dropdown-menu dropdown-menu-left">
                                        `+menu+`
                                    </ul>
                                </li>
                            </ul>`;
                	}
            	},
            	{ "data" : "bank",
             		render:function(data, type, full, meta){
             		    return full.product;
                	}
            	},
                { "data" : "option1"},
                { "data" : "bank",
                    render:function(data, type, full, meta){
                        if(full.product == "matm" && full.status == "failed"){
                            var out =  `<a href="javascript:void(0)" class="viewreport" data-popup="tooltip" title="" data-original-title="View report" >`+full.txnid+`</a>`;
                        }else{
                            var out =  `<a href="javascript:void(0)" class="viewreport" data-popup="tooltip" title="" data-original-title="View report">`+full.txnid+`</a>`;
                        }

                        return out;
                    }
                },
                { "data" : "payid"},
                { "data" : "bank",
                    render:function(data, type, full, meta){
                        var out = "";
                        if(full.status == "success"){
                            var out = `<span class="label label-success">Success</span>`;
                        }else if(full.status == "accept"){
                            var out = `<span class="label label-info">Accept</span>`;
                        }else if(full.status == "pending"){
                            var out = `<span class="label label-warning">Pending</span>`;
                        }else if(full.status == "reversed" || full.status == "refunded"){
                            var out = `<span class="label bg-slate">`+full.status+`</span>`;
                        }else{
                            var out = `<span class="label label-danger">`+full.status+`</span>`;
                        }

                        return  out;
                    }
                },
                { "data" : "refno"},
                { "data" : "amount"},
                { "data" : "created_at"},
                { "data" : "remark"}
            ];

            DT = datatableSetup(url, options, onDraw);
        });
    </script>
@endpush