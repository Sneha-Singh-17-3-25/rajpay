@extends('layouts.app')
@section('title', 'Coming Soon')
@section('pagetitle', 'Coming Soon')
@section('content')
    <div class="content">
        <img src="{{asset('assets/comingsoon.png')}}" class="img-responsive">
    </div>
@endsection
